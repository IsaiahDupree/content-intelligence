# Reproducibility log

All runtime checks were constrained to offline or local help/read paths. Credential variables were removed for provider-sensitive checks. No account write, submission, upload, generation, payment, or service-start path was invoked.

## Acquisition and provenance

Each origin was checked with `git ls-remote --symref <origin> HEAD`. Each unique target was then created with:

```sh
git -c core.hooksPath=/dev/null clone --depth 1 --no-tags <origin> <unique-target>
```

Local provenance and state were checked with:

```sh
git remote get-url origin
git branch --show-current
git rev-parse HEAD
git log -1 --format=%cI
git status --short
```

All four local HEADs matched the remote `main` HEADs observed before cloning.

## Static Python validation

The following pattern was run for the Rushant, Vanszs, and Coleam sources, with a distinct cache directory for each:

```sh
env PYTHONPYCACHEPREFIX=/tmp/content-factory-audit-<name>-pycache python3.11 -m compileall -q .
```

All three commands exited zero. Compilation does not import or execute the modules.

## Socheli

Dependency setup used the committed lock and disabled lifecycle hooks.

The root typecheck was run with `pnpm typecheck` and exited zero after the documented TypeScript exclude change.

`git diff --check` also exited zero.

The content CLI help command exited zero with provider variables removed.

It also seeded the tracked brand data file. The audit restored that file to its committed empty state.

The registry reported 316 capabilities. A local analytics lookup for a missing audit identifier returned null without error.

Calling `packages/engine/scripts/whisper-words.py` without arguments returned its expected usage exit.

## Vanszs scaffold

A Python 3.11 environment lives at `audits/factory_lane/.venvs/tiktok`. Only `pydantic`, `pydantic-settings`, and `langchain-openai` plus their required packages were installed from binary distributions.

Settings/schema import checks passed. The model helper rejected the credentials-removed setup before any request.

These advertised entries were checked and failed with missing-module errors, confirming that the README describes absent code:

```sh
python -m workflows.faceless --help
python -m workflows.batch --help
python -m workflows.clipping --help
python -m mcp_bridge.server --help
```

## Coleam factory

A Python 3.11 environment lives at `audits/factory_lane/.venvs/ai_content`.

The factory status reader exited zero. Both animation entries returned expected usage exits because no inputs were supplied. Nothing was generated or submitted.
