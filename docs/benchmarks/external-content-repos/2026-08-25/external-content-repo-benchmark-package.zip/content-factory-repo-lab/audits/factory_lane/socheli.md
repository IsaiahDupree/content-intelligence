# Socheli

- Branch: `main`
- HEAD: `8cd7cc136bce43fbc95e30dc1bb4c5adfe4067ae`
- Commit date: `2026-06-16T10:00:00Z`
- Source URL: `https://github.com/Socheli/socheli.git`
- Local status: one documented compatibility change in `tsconfig.base.json`

## License boundary

`LICENSING.md` assigns AGPL-3.0 to the engine, dashboard, Remotion package, and remaining source. It assigns MIT to `packages/cli`, `packages/sdk`, `packages/mcp`, `packages/api`, `packages/schemas`, `packages/tokens`, and `apps/mobile`.

The safest integration pattern is a separate AGPL service called through an MIT client surface, unless the deployment complies with AGPL obligations.

## Implemented generation path

The implementation is substantive rather than a roadmap scaffold:

- `packages/engine/src/run.ts` invokes the script-writing stage.
- `packages/engine/src/stages.ts` contains provider-backed planning and generation stages.
- The registry exposes `draft_script` and the wider production workflow.
- Human approval and brand-DNA gates are explicit workflow boundaries.

This is the only assigned source that can plausibly generate three original scripts with its documented provider configuration. No provider-backed generation was started during this audit.

## Transcript path

`packages/engine/src/editor-tools.ts` implements audio transcription.

`packages/engine/scripts/whisper-words.py` emits word and segment timing.

The understanding tools add shot, highlight, filler, and dead-air analysis.

A fresh clone is not transcription-ready.

The TypeScript call assumes `.venv-music/bin/python`, while the Python helper imports `mlx_whisper`. No repository requirements file or setup command provisions that environment.

Calling the helper without arguments returned its usage message and did not handle an input file.

## Analytics path

The analytics path is implemented:

- `analytics_ingest` accepts result data.
- `packages/engine/src/learnings.ts` normalizes metrics and records performance.
- Stored performance can influence prompt memory and brand-DNA evolution.

The loop still has adapter gaps. An initial delivery response can provide one identifier while later metric lookup may require a different platform video identifier. Some retention measures cannot be derived when duration is absent.

## Install and offline validation

Repository guidance was read and followed.

Dependencies were installed from the lock.

Lifecycle hooks remained disabled.

The supply-chain policy accepted all 685 lock entries.

The registry loaded 316 tools: 118 read, 135 mutate, and 63 long-running.

The content command help check passed with provider variables removed.

That help path also seeded default records into `data/brands.json`. The audit restored the tracked file to its original empty state; CLI startup should be treated as stateful.

An offline missing-record analytics read returned a clean null result.

No external account action or paid generation was run.

The repository has almost no conventional automated engine tests. Typechecking and narrow offline command checks are therefore the strongest native validations available.

## Compatibility change

The root TypeScript configuration included all app source directories even though the workspace excludes standalone `apps/mobile`. That pulled uninstalled Expo dependencies into the root typecheck.

The local change adds `apps/mobile` to the root exclude list. After that change, the advertised root typecheck and `git diff --check` both pass.

## Reuse decision

Reuse the typed workflow contracts, human gates, transcription data shape, analytics normalization, and learning-memory design. Resolve the Whisper environment contract and platform metric identifiers before treating the loop as production-ready.
