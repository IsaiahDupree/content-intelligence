# Rushant multi-engine suite

- Branch: `main`
- Origin: GitHub owner `Rushant-123`, assigned multi-engine suite
- HEAD: `a79f6cf5bec573f962c8100efde2045810c62c35`
- Commit date: `2026-01-27T21:56:07+05:30`
- Local status: clean
- Size inspected: 92 Python files, 18,631 Python lines

## Quarantine finding

`asmr-compilations/config.py` appears to contain a committed Instagram access token together with host/account configuration. The token value is not present in this audit and no posting code was executed. Treat it as compromised: revoke/rotate it, remove it from the current tree and history, and replace it with environment-only loading before any runtime evaluation.

There is no root license file. The only license file is an MIT license inside `reddit-screenshots/`, so it does not establish reuse rights for the other engines. A README statement is not a replacement for a repository license file.

## Implemented surfaces

The codebase is seven mostly independent Python services, not one coordinated factory:

- `ai-poetry/main.py`: FastAPI poetry/video service.
- `asmr-compilations/main.py` and `api.py`: video processing and an upload proxy.
- `gym-memes/main.py`: source download, processing, validation, and object-storage upload.
- `linkedin-quotes/cli.py`: quote-card/reel processing and object-storage handoff.
- `reddit-reposter/app.py`: Flask source-content service.
- `reddit-screenshots/video_creator.py`: screenshot video creation and upload proxy.
- `travel-edits/main.py`: source selection, captions, editing, and upload handoff.

The README says the general engine is 46K lines. The entire repository is 18,631 Python lines and `reddit-reposter/app.py` is 1,060 lines at this HEAD.

## Script, transcript, and analytics

- The poetry service calls an LLM for poem selection/recitation.
- The travel service creates a caption.

Other engines repurpose source text. No speech-to-text, transcript segmentation, or general script-generator implementation was found.

The repository has no outcome-to-generation loop.

Travel popularity fields concern input selection. CouchDB views are indexes and deduplication, not audience outcomes.

## Install safety and validation

- Seven requirements files contain conflicting exact versions; each engine needs its own Python 3.11 environment.
- Requirements have no hashes or aggregate lock, and several packages are old.
- Setup and deployment scripts can invoke global installers, elevated privileges, firewalls, system services, Docker, remote downloads, and wide network binds.
- Several files named as tests are live integration scripts, not offline unit tests.
- Only four service areas expose obvious health routes; there is no uniform suite contract.

Static Python 3.11 compilation of every Python file succeeded with bytecode written outside the clone. No repository program was run.

## Reuse decision

Credential rotation and license clarification must happen first.

The source does not provide a reusable transcript engine or an owned-results learning loop.
