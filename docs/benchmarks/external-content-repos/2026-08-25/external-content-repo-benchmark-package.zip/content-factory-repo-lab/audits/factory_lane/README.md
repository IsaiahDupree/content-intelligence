# Factory lane audit

Date: 2026-08-25

Scope was confined to the assigned source and audit directories. No provider credentials were used, no publishing calls were made, and no paid generation was started.

## Provenance

- Rushant suite: `a79f6cf5bec573f962c8100efde2045810c62c35`.
- Socheli: `8cd7cc136bce43fbc95e30dc1bb4c5adfe4067ae`.
- Vanszs scaffold: `14762edc1cfd9dad7ace201d8d591539b99cba2f`.
- Coleam factory: `3c6edf6d73f1d54f636c55f07b8f2a7d12e47afb`.

All four remotes resolved to `main`, and each local HEAD matched the remote HEAD returned before cloning.

Rushant suite is quarantine-only and lacks a root license.

Socheli is substantive and uses a split AGPL/MIT license model.

The Vanszs source is a scaffold and has no license file.

The Coleam source is an MIT production/QA demo without an outcome-learning loop.

## Transcript readiness

- Rushant: no general script or speech-to-text engine.
- Socheli: real hook/script stages; transcription code needs an unprovisioned local Whisper environment.
- Vanszs: schemas only; the advertised workflow files are absent.
- Coleam: six fixed UGC lines and a catalog fallback, not a general generator or transcriber.

Only Socheli is ready to generate three original scripts after its model-provider gate is configured. The other sources must not be represented as equivalent transcript engines.

## Local code change

Only Socheli was modified. Its root typecheck included the standalone Expo app even though the workspace excludes it. `tsconfig.base.json` now excludes that app, and the exact advertised typecheck passes. No other clone has a diff.

Detailed findings:

- [rushant.md](rushant.md)
- [socheli.md](socheli.md)
- [vanszs.md](vanszs.md)
- [coleam.md](coleam.md)
- [commands.md](commands.md)
