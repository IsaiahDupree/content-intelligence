# Coleam AI content factory

- Branch: `main`
- HEAD: `3c6edf6d73f1d54f636c55f07b8f2a7d12e47afb`
- Commit date: `2026-07-12T08:16:14-05:00`
- Source URL: `https://github.com/coleam00/ai-content-factory.git`
- License: MIT
- Local status: clean
- Size inspected: 15 Python files and 1,842 Python lines, plus generated example assets

## Script and transcript findings

`animate_ugc.py` contains six fixed product-specific spoken lines plus a catalog-based fallback. These are short copy templates, not a general script or hook generator.

No speech-to-text, transcript, word-timing, segmentation, or transcript-comparison path exists.

## Analytics findings

The project tracks internal production quality and state: visual judgments, duration, file integrity, queue counts, and projected cost.

It does not ingest views, retention, engagement, conversion, or other audience outcomes. Observed audience performance cannot influence later concepts.

## Offline validation

A dedicated Python 3.11 environment was created under the audit directory.

- Static Python compilation passed.
- The worker help command passed with credentials removed.
- The read-only factory status command passed.
- The fixture reports 20 products, 40 concepts, 12 approvals, 12 completed renders, no pending items, and no integrity issues.
- Both animation commands returned their expected usage error when called without arguments.
- No generation, payment, login, service start, or external account action was attempted.

There is no conventional automated test suite or locked environment. Some scripts dynamically resolve dependencies, and a global third-party command is assumed rather than pinned.

## Reuse decision

Reuse the cheap-exploration gate, atomic claims, idempotent workers, approval queue, and production-quality checks. Supply an independent script/transcript layer and an audience-results loop; this source does not provide either.

## Implemented surface

This is a filesystem-backed concept tournament and rendering demonstration:

- Generate low-cost concept images before expensive animation.
- Keep approval as a deliberate gate.
- Claim jobs atomically and make workers idempotent.
- Support product-ad and UGC-style output paths.
- Apply visual-quality, duration, and file-integrity gates.
- Expose a read-only status view with queue and cost summaries.
