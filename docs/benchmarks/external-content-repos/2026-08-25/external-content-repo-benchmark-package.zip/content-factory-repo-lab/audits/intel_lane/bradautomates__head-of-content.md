# Audit: bradautomates/head-of-content

Audit date: 2026-08-25

## Verdict

Checkout inspection and isolated verification work. Production integration is blocked pending packaging, dependency locking, transcript-to-analysis wiring, and retrieval hardening.

## Provenance

- Clone: sources/bradautomates__head-of-content
- Remote: https://github.com/bradautomates/head-of-content.git
- Branch: main, tracking origin/main
- HEAD: d841dcff2e4d74a4c31cb3ed2de6c2184de3a970
- Commit time: 2026-01-23T14:19:00+10:00
- AGENTS.md: none found
- License: MIT; LICENSE file present.

Classification: competitor-scouting layer with platform-specific outlier formulas and a structured analysis rubric.

## Transcript and script entry points

The YouTube find_outliers.py entry requests timestamped transcripts through TubeLab and saves them for selected outlier videos. Credentials and external service access are required; the path was not invoked. Local speech-to-text fallback: absent.

The video-content-analyzer analyze_videos.py entry ignores the saved transcript_path. Its YouTube mapping supplies a provider-page URL. A generic fallback can receive HTML and label the temporary result video/mp4. The advertised YouTube analysis is therefore unreliable as wired.

The content-planner bundle is an agent instruction and output template for ideas, hooks, and playbooks. A standalone deterministic full-script or three-transcript command is absent.

## Analytics findings

- Competitor score forms: weighted engagement, mean plus two standard deviations, and z-score times recency.
- Owned-post result ingestion: absent.
- Retention and conversion storage: absent.
- Outcome-driven model update: absent.
- Committed raw outcome dataset: absent.

## Dependency and security review

- Distribution form: ZIP bundles.
- Entry-name traversal: none found.
- Extraction location: clone-local _audit_unpacked.
- Python manifest or lockfile: absent.
- Clone-local Python 3.11 environment used.
- Wheel-only installation and pip check: passed.
- Obvious plaintext secret in tracked files: none found.

- Bytecode artifacts are committed in two bundles; remove before reuse.
- HTTP retrieval paths lack strict URL, redirect, MIME, byte, and time limits.
- Source text requires untrusted-input isolation before model prompts.
- An automatic macOS sound hook is configured; exclude automatic shell hooks from integration.
- Documentation contains unsafe environment-loading and credential-prefix display patterns; do not adopt them.

No external provider request, source-content retrieval, render, publish action, or model call was performed.

## Offline verification

- Safe ZIP entry inspection: passed.
- Python compilation: passed.
- CLI help for nine scripts: passed.
- pip check: passed.

These checks validate import and argument parsing only. Provider responses and transcript quality remain untested.

## Commands executed

    git remote get-url origin
    git rev-parse HEAD
    git status --short --branch
    find . -name AGENTS.md -print
    find . -name '*.skill' -print0 | xargs -0 -n1 zipinfo -1
    python3.11 -m venv .audit-venv
    .audit-venv/bin/python -m pip install --only-binary=:all: apify-client google-genai requests python-dotenv
    .audit-venv/bin/python -m pip check
    .audit-venv/bin/python -m compileall -q _audit_unpacked
    while IFS= read -r script; do .audit-venv/bin/python "$script" --help >/dev/null; done < <(find _audit_unpacked -path '*/scripts/*.py' -type f -not -path '*/__pycache__/*' -print)

## Clone changes

No tracked file changed. .audit-venv and _audit_unpacked are untracked clone-local artifacts. No compatibility patch was applied.

## Integration gate

Required before use: maintained package structure, locked dependencies, explicit transcript_path input to analysis, rejection of HTML mislabeled as video, deterministic transcript fixtures, validated external retrieval, untrusted-input boundaries, real provider tests, authentication, and /api/health.
