# Audit: intelligent-iterations/content-gen

Audit date: 2026-08-25

## Verdict

The checkout and isolated verification work. Production integration is blocked because this repository has no executable transcript ingestion, no automated audience-results collector, a vulnerable dependency lock, and an incomplete license distribution.

## Provenance

- Clone: sources/intelligent-iterations__content-gen
- Remote: https://github.com/intelligent-iterations/content-gen.git
- Branch: main, tracking origin/main
- HEAD: 9424c4de6d4e29ffaa9172e20884a554bcc8262f
- Commit time: 2026-03-08T13:55:35-04:00
- Subject: Add data source screenshots for verification
- AGENTS.md: none found
- License: README.md and package.json declare MIT, but no LICENSE or COPYING file is present.

Resolve the missing license text and copyright notice before copying source into a canonical project.

## Transcript and script entry points

Entry file: code/ai-orchestrator.js.

- Purpose: model-assisted carousel generation and quality iteration.
- External requirements: model and image-provider APIs.

Second entry file: code/generate-video.js.

- Generated production plan: implemented.
- Existing-video transcription: absent.
- Requested three-transcript output: absent.

Performance-memory findings:

- code/prompts.js parses manual metrics from CURRENT_POSTED_VIDEOS.md.
- Only POSTED_VIDEOS.example.md is committed.
- Parsed summaries are absent from the next generation prompt.
- code/ai-orchestrator.js initializes completion, save, comment, and like fields to null for later manual entry.
- Platform collector, attribution layer, and automatic memory update: absent.

## Analytics claims and evidence

TECHNICAL_PAPER.md reports 100 AI posts and 82,967 total views as of 2026-03-08: 18,916 on TikTok and 64,051 on Instagram. It also reports averages of 573 and 955 views respectively, a top post around 12,200, and four-slide completion around 50–65 percent versus about 23–30 percent for nine- or ten-slide posts.

Two static platform screenshots partially corroborate individual posting activity. They do not reproduce the stated aggregate and date range, supply raw exports, or establish causal attribution. Evidence grade: manual experiment report, not reproducible dataset.

## Dependency and security review

- The committed JavaScript lock was installed with lifecycle scripts disabled and no global install.
- The lock reports 35 advisories: 1 low, 13 moderate, 17 high, and 4 critical.
- Direct affected packages include axios, express, firebase-admin, a page-automation package, and sharp.
- Network generation, social posting, preview launching, rendering, scraping, and paid provider paths were not run.
- test-grok reveals a credential prefix in logs; a demo path can write environment configuration.
- Some shell-string command construction should become explicit argument arrays.
- No obvious plaintext secret was found in tracked files.
- Authenticated service boundary and /api/health: absent.

## Offline verification

Successful:

- JavaScript syntax validation across code, n8n, tiktok-callback, and scripts.
- Python compilation across code, scripts, and tiktok-callback.
- node code/test-overlay.js, producing three ignored local JPEG fixtures.
- Top-level dependency-tree validation.

No network request, scrape, post, render, or model call was performed.

## Commands executed

    git remote get-url origin
    git rev-parse HEAD
    git status --short --branch
    find . -name AGENTS.md -print

    npm ci --ignore-scripts --no-audit --no-fund
    npm ls --depth=0
    npm audit --json

    find code n8n tiktok-callback scripts -type f \( -name '*.js' -o -name '*.mjs' \) -print0 | xargs -0 -n1 node --check
    python3.11 -m compileall -q code scripts tiktok-callback
    node code/test-overlay.js

## Clone changes

No tracked file changed. Clone-local install and test artifacts are ignored. No compatibility patch was applied.

## Integration gate

Required before use: resolve the license distribution, patch dependencies, implement transcript ingestion, implement measured-result attribution, fail closed when credentials are missing, and add authentication plus /api/health.
