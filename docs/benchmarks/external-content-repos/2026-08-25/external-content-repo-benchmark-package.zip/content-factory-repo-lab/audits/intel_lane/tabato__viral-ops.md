# Audit: tabato/viral-ops

Audit date: 2026-08-25

## Verdict

Checkout inspection, isolated editable installation, Python compilation, CLI help, and the native unit suite work. The core provides competitor virality normalization but no transcript ingestion, direct video-content analysis, owned-post analytics, or closed feedback loop.

This is the cleanest executable intelligence core in this lane, but its model analysis is metadata-based. Claims about exact spoken openings, visuals, pacing, or retention mechanisms remain hypotheses unless independently verified.

## Provenance

- Clone: sources/tabato__viral-ops
- Remote: https://github.com/tabato/viral-ops.git
- Branch: main, tracking origin/main
- HEAD: 373c900d80cfb2b57bd17fa5be6d4ce4fb07455c
- Commit time: 2026-05-24T22:47:30-04:00
- Subject: fix: handle Anthropic 529 overloaded error with a clear retry message
- AGENTS.md: none found
- License: MIT; LICENSE file present.

## Transcript and script entry points

Native transcript entry: absent. The README describes metadata retrieval rather than video downloading.

viral_ops/scanner.py separates Shorts from long-form content before computing:

    virality score = video views / channel average for comparable content

viral_ops/analyzer.py supplies title, channel, views, virality score, and a description excerpt to a model. Its outputs are hook reasoning, three adaptation angles, a proposed title, a two-sentence opening, and structural direction.

Classification: copy-angle blueprint, not a full transcript or production script. Requested three-transcript support: absent.

## Analytics claims and evidence

- README claim: 2,500+ source items, 130+ outliers, 30 copy angles, about 30 seconds.
- Committed outliers.json corpus: absent.
- Committed swipe_file.md corpus: absent.
- Outcome ingestion: absent.
- Retention and conversion fields: absent.
- Model feedback: absent.
- Sample blueprint.md: present; output-shape example only.

## Dependency and security review

- Clone-local Python 3.11 environment and wheel-only editable installation.
- pip check: passed.
- Dependency policy: lower bounds, no resolved lock.
- Provider packages: all supported clients installed even when one is selected.
- YAML parser: safe_load.
- Generated-report field escaping: present.
- Generated report auto-launch: enabled by default; require explicit suppression in this workspace.
- Remote asset retrieval lacks strict host, redirect, MIME, size, and time limits.
- Obvious plaintext secret in tracked files: none found.
- Upstream unit tests use mocks; real integration tests remain required by workspace policy.

No external scan, model call, download, automatic report launch, or publishing action was performed.

## Offline verification

- Python compilation: passed.
- pip check: passed.
- viral-ops --help: passed.
- pytest -q: 67 passed in 1.60 seconds.

The unit suite validates isolated logic but not provider integrations.

## Commands executed

    git remote get-url origin
    git rev-parse HEAD
    git status --short --branch
    find . -name AGENTS.md -print
    python3.11 -m venv .audit-venv
    .audit-venv/bin/python -m pip install --only-binary=:all: -e '.[dev]'
    .audit-venv/bin/python -m pip check
    .audit-venv/bin/python -m compileall -q viral_ops tests
    .audit-venv/bin/pytest -q
    .audit-venv/bin/viral-ops --help

## Clone changes

No tracked file changed. .audit-venv is an untracked clone-local artifact. No compatibility patch was applied.

## Integration gate

Suitable principles after hardening: channel-baseline normalization, Shorts/long-form separation, and outlier selection. Required changes: locked provider-specific dependencies, report auto-launch disabled, hardened external retrieval, explicit metadata-derived evidence labels, transcript/frame analysis before content-level claims, real integration tests, owned-result attribution, authentication, and /api/health.
