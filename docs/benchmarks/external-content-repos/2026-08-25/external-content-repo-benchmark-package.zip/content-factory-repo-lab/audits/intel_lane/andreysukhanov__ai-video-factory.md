# Audit: AndreySukhanov/ai-video-factory

Audit date: 2026-08-25

## Verdict

The isolated backend install, application import, in-process health check, frontend install, lint, and typecheck work. Transcript extraction code exists. Production integration is legally and technically blocked.

## Provenance

- Clone: sources/andreysukhanov__ai-video-factory
- Remote: https://github.com/AndreySukhanov/ai-video-factory.git
- Branch: main, tracking origin/main
- HEAD: ee0c354a50722fa67128165e2e104e3423cd54fc
- Commit time: 2026-07-07T16:13:40+04:00
- Subject: chore(deps): upgrade Next.js to 16.2.10 and patch transitive deps
- AGENTS.md: none found
- License: custom Source-Available License.

The LICENSE forbids using any part of this software in a product, service, application, workflow, pipeline, or other system, whether commercial or non-commercial. It also restricts copying, modification, derivative works, and model training without written permission. This checkout was audited in isolation only. Written permission is a hard prerequisite for integration.

## Transcript and script entry points

backend/app/services/trendwatcher/pattern_extractor.py implements:

- YouTube transcript retrieval with youtube-transcript-api.
- TikTok and Instagram audio retrieval with yt-dlp plus local faster-whisper transcription.
- Title-and-description fallback.
- Representative-frame and transcript analysis.
- Structured hook, visual style, story beat, pacing, call-to-action, and on-screen-text extraction.

backend/app/models/trend_pattern.py stores transcript and transcript_source. The trends API includes a clone-brief route. backend/app/ai_orchestrator/agents/story_generator.py produces episode and script structures from the stored patterns.

Those paths require external source retrieval or paid provider calls and were not invoked. The requested three-transcript corpus was not generated in this lane.

## Production-data integrity

backend/app/ai_orchestrator/llm_client.py silently selects mock generation when a key is absent or an API request fails. A mock video provider is also present and the real provider remains incomplete. This conflicts with the workspace prohibition on mock production data. A compliant implementation must fail closed and keep test fixtures outside production records.

## Analytics findings

backend/app/models/analytics.py stores views, likes, comments, shares, watch time, average view duration, click-through rate, impressions, and subscribers. backend/app/services/youtube/analytics.py contains YouTube statistics and channel-owner analytics collection.

The analytics request asks only for estimatedMinutesWatched, averageViewDuration, shares, and subscribersGained. Its caller additionally reads cardClickRate and impressions, so those two values become zero instead of measured results.

The README lists the CTR/retention feedback loop and automatic hook A/B testing as roadmap items. No current path attributes outcomes back to patterns or script generation. pipeline_test_results.json records three generation executions and URLs, not audience views, retention, or conversions.

## Dependency and security review

Backend:

- Python 3.11 environment isolated at backend/.audit-venv.
- Wheel-only installation; pip check passed.
- requirements.txt is unpinned and has no resolved lock.

Frontend:

- Committed lock installed with lifecycle scripts disabled.
- Top-level dependency validation passed.
- Six high-severity advisories affect brace-expansion, js-yaml, nanoid, Next.js, postcss, and sharp.
- npm reports a patched semver-minor Next.js release.

Runtime:

- API authentication is optional.
- docker-compose.yml exposes Redis, backend, and frontend through all-interface bindings.
- Deployment scripts contain privileged Docker installation and sshpass commands.
- Several FFmpeg paths use shell=True.
- Remote retrieval requires URL, redirect, MIME, and byte-limit hardening.
- No obvious plaintext secret was found in tracked files.

No deployment script or external retrieval path was run.

## Offline verification

Successful:

- Backend Python compilation.
- FastAPI application import with 21 registered routes.
- In-process GET /health: HTTP 200, status ok, service AI Video Factory.
- Frontend typecheck with zero errors.
- Frontend lint with zero errors and ten warnings.
- pip check and top-level JavaScript dependency validation.

Application import reported selection of the mock provider because no keys were configured. This confirms fail-open behavior; it is not a production-provider test.

No native pytest suite exists. generate_test_video.py was not run because it invokes a paid Replicate path. The frontend production build was not run because its font step can fetch from the network.

## Commands executed

From the repository root:

    git remote get-url origin
    git rev-parse HEAD
    git status --short --branch
    find . -name AGENTS.md -print
    python3.11 -m venv backend/.audit-venv
    backend/.audit-venv/bin/python -m pip install --only-binary=:all: -r backend/requirements.txt
    backend/.audit-venv/bin/python -m pip check
    backend/.audit-venv/bin/python -m compileall -q backend/app

The health request used an in-process FastAPI TestClient; no service process was started.

From frontend:

    npm ci --ignore-scripts --no-audit --no-fund
    npm ls --depth=0
    npm audit --json
    npm run lint
    ./node_modules/.bin/tsc --noEmit

## Clone changes

No tracked file changed. The Python environment, ignored SQLite file, and JavaScript install tree are clone-local artifacts. No compatibility patch was applied.

## Integration gate

Mandatory: written permission. Technical gates after permission: fail-closed providers, locked and patched dependencies, corrected analytics requests, outcome feedback, required authentication, restricted service exposure, argument-array process calls, hardened external retrieval, and real integration tests.
