# MoneyPrinterTurbo audit

Audited 2026-08-25 at commit `6cd36b5a2c56b49b24621463038e4db3963f0a43` (`main`).

## Verdict

Promising after hardening, but do not run as a service or publish from it yet. Its locked environment currently carries material advisories, its direct-run API defaults to all interfaces with authentication disabled, and the bundled music has unresolved reuse rights.

## Verification

- Shallow clone used disabled Git hooks. The exact `uv.lock` was installed immutably into `.venv-audit` without building the project; all 117 packages passed `uv pip check`.
- Network-blocked suite: **764 passed, 11 skipped, 6,975 subtests passed** with 9 warnings.
- A socket-blocked FastAPI smoke test passed `/ping`; it also confirmed that default config leaves `GET /api/v1/tasks` unauthenticated and sets `listen_host` to `0.0.0.0`.
- Gitleaks found no credential leak.
- Pip-audit reported **61 advisory records across 8 locked packages**. Runtime-impacting packages were `aiohttp 3.14.0`, `click 8.1.8`, `cryptography 49.0.0`, `GitPython 3.1.50`, `Pillow 11.3.0`, `python-multipart 0.0.27`, and `starlette 1.2.1`; the eighth was environment tooling (`setuptools 82.0.1`). Advisory state is as of the audit date.

## Material findings

- **High — exposed unauthenticated default:** `config.example.toml:10-26` uses `0.0.0.0` and an empty API key. `app/asgi.py:25-35` explicitly disables authentication for an empty key, while `app/asgi.py:108-117` defaults CORS to `*` with credentials, methods, and headers enabled.
- **High — vulnerable lock:** upgrade the affected packages. Latest listed minimum fixes include aiohttp 3.14.3, click 8.3.3, cryptography 50.0.0, GitPython 3.1.58, Pillow 12.3.0, python-multipart 0.0.31, Starlette 1.3.1, and setuptools 83.0.0. Regenerate the lock and rerun the full suite before deployment.
- **High — music rights unresolved:** 29 MP3s are bundled in `resource/songs`; `README-en.md:424-429` says they came from YouTube videos and provides no per-track license notices. Do not publish with them.
- **High — optional automatic public publishing:** docs enable one-click cross-posting and set YouTube privacy to public (`README-en.md:439-453`; `config.example.toml:313-327`). It is off by default, but must remain unavailable until dry-run, preview, approval, and audit logging gates exist.
- **Medium — container hardening:** the Dockerfile uses old Debian bullseye, runs as root, and grants mode 777 to the app directory (`Dockerfile:2-8`). Release compose pulls mutable `:latest` images. The compose port mappings do correctly restrict host exposure to `127.0.0.1`.
- **Low — surprising deletion:** config loading recursively deletes a path named `config.toml` if it is a directory (`app/config/config.py:460-469`).
- The upstream suite relies heavily on simulated providers. Keep it as regression evidence, but it does not satisfy the workspace requirement for real local integration tests by itself.

## Safe-use gate

Bind direct runs to `127.0.0.1`; require a nonempty high-entropy API key; restrict CORS; upgrade and relock dependencies; replace bundled music with explicitly licensed assets; pin container image digests and run non-root; disable cross-posting in code unless an approved publish workflow invokes it; and add real local-provider/test-server integrations.
