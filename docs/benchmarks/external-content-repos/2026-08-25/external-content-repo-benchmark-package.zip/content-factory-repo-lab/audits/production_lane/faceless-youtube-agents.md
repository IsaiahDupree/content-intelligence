# faceless-youtube-agents audit

Audited 2026-08-25 at commit `e92c84537996217dd6fff60da9acc87198022b0b` (`main`).

## Verdict

Sandbox-only; do not integrate or publish from the repository unchanged. The local assembly primitives work, but the project has no license, no upstream tests, unpinned dependencies, a path-containment flaw, and a credential-triggered upload path with no per-run approval gate.

## Verification

- Shallow clone used disabled Git hooks. Dependencies were installed wheel-only into `.venv-audit`; no credentials were inherited or loaded.
- `pip check` and `compileall` passed. The repository has no test suite.
- `pipeline.py --check` correctly found local FFmpeg tools and refused cloud stages without Gathos credentials.
- A socket-blocked smoke test exercised URL/VTT/slug helpers and rendered a real local MP4 with FFmpeg: `results/production_lane/faceless-youtube-agents/clip.mp4`.
- Gitleaks found no credential leak. Pip-audit found no advisory in the two declared runtime dependencies; its findings were confined to the audit environment's `pip`/`setuptools` bootstrap tools.

## Material findings

- **Blocker — no license:** the repository contains no `LICENSE` or equivalent grant. Reuse, modification, and distribution rights are therefore not established.
- **High — automatic external write:** `pipeline.py:189-231,235-251` uploads a private YouTube draft whenever all three YouTube credentials exist; `--run-all` has no fresh approval/preview gate.
- **High — path traversal:** caller-controlled `--run-id` is interpolated into state paths without resolving and checking containment (`lib/state.py:44-46,88-92`).
- **Medium — dormant file exfiltration helper:** the helper at `lib/` under the file name ending in `_host.py` can upload arbitrary local files and defaults to file.io. It is currently imported but unused; remove it before adoption.
- **Medium — weak reproducibility:** `requirements.txt` contains only minimum versions and no lock or hashes.
- **Medium — unsafe shared temp names:** transcript downloads use predictable filenames in the system temp directory (`lib/channel_analyzer.py:9,49-80`), allowing stale-file and concurrent-run collisions.
- This is primarily an agent playbook plus assembly scripts; “viral DNA” analysis and script creation are performed by the calling coding agent, not by a self-contained orchestrator.

## Safe-use gate

Obtain an explicit license; validate and contain every run path; remove the public upload helper; add a dry-run plus human approval boundary before every provider/upload call; pin dependencies; add real local integration tests; and apply the workspace content-reference copy gate before using creator examples. Never reuse source clips, identity, likeness, or voice.
