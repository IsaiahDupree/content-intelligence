# OpenMontage audit

Audited 2026-08-25 at commit `cd9f3c1f03368be87b140af494914b8ee4e3c7a4` (`main`).

## Verdict

Technically mature and the strongest offline-tested design in this lane, but conditionally usable only as isolated, non-GUI tooling. Do not merge it into proprietary ACTP code until AGPL obligations are reviewed; do not use its GUI or render launchers until they conform to the workspace singleton policy.

## Verification

- Shallow clone used disabled Git hooks. Python dependencies were installed wheel-only into `.venv-audit`; Remotion dependencies used the committed lock with `npm ci --ignore-scripts --no-audit --no-fund`.
- Effective Python result: **1,829 passed, 11 skipped, 3 xfailed**. The initial sanitized run had three font-only failures because macOS/Pygments expects `HOME`; rerunning only those tests with the real home path, still without credentials and with sockets blocked, passed.
- Remotion TypeScript `tsc --noEmit`, `npm ls`, and a production npm audit passed; npm reported 0 vulnerabilities.
- A socket-blocked smoke test exercised Backlot health and built a local `ExportBundle` from the faceless smoke clip: `results/production_lane/OpenMontage/export/`.
- Gitleaks produced 23 redacted hits; manual review found only documentation placeholders, test fixtures, and public/internal constants. No live credential was identified.
- Pip-audit found no advisory in declared runtime/test dependencies; findings were confined to the audit environment's `pip`/`setuptools` bootstrap tools.

## Material findings

- **Blocker for proprietary integration — AGPL-3.0:** network use and modification can create source-disclosure obligations. Keep it segregated pending counsel or review.
- **High — singleton-policy conflict:** `backlot open` starts a detached server and invokes the OS URL opener (`backlot/__main__.py:38-75`). Remotion and HyperFrames render paths can also start GUI runtimes. None were run because the workspace requires a claimed singleton target.
- **High — install/preflight network side effects:** the official setup uses unpinned `pip install`, `npm install`, unpinned `piper-tts`, and `npx --yes hyperframes` (`Makefile:54-70`). HyperFrames availability checks call `npm view` (`tools/video/hyperframes_compose.py:272-321`), so even provider preflight reaches the registry.
- **Medium — incomplete package metadata:** `setup.py:9-18` omits dependencies present in `requirements.txt`, so `pip install .` alone is not a complete installation.
- **Medium — weak Python reproducibility:** requirements use lower bounds rather than a lock or hashes.
- Many tools accept explicit arbitrary output paths; safety is enforced mainly by agent instructions rather than a central path-containment layer.

## Safe-use gate

Resolve AGPL compatibility; replace the setup flow with locked, hash-checked installs; make provider checks offline by default; route every GUI action through the approved claim/act/release service; centralize output containment; and add ACTP-specific real local integration coverage. The local export/bundle, metadata, validation, and non-GUI orchestration components are the safest candidates for evaluation.
